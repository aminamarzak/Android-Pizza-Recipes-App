package com.example.pizzarecipes.service;

import com.example.pizzarecipes.R;
import com.example.pizzarecipes.classes.produit;
import com.example.pizzarecipes.dao.IDao;
import java.util.ArrayList;
import java.util.List;

public class ProduitService implements IDao<produit> {
    private static ProduitService INSTANCE;
    private final List<produit> data = new ArrayList<>();

    private ProduitService() { seed(); }

    public static ProduitService getInstance() {
        if (INSTANCE == null) INSTANCE = new ProduitService();
        return INSTANCE;
    }

    private void seed() {
        // Hna t-at-zid l-ingredients f l-parameter l-khamess (5)
        data.add(new produit("BARBECUED CHICKEN", 3.0, R.mipmap.pizza1, "35 min",
                "Poulet, Sauce BBQ, Oignons, Mozzarella",
                "Une pizza fumée et délicieuse.", "1. Etaler la pâte..."));

        data.add(new produit("BRUSCHETTA PIZZA", 5.0, R.mipmap.pizza2, "45 min",
                "Tomates, Ail, Basilic, Huile d'olive",
                "Le goût de l'Italie dans chaque bouchée.", "1. Couper les tomates..."));

        data.add(new produit("SPINACH PIZZA", 2.0, R.mipmap.pizza3, "25 min",
                "Épinards frais, Crème, Parmesan",
                "Légère et saine.", "1. Laver les épinards..."));
    }

    @Override public produit create(produit p) { data.add(p); return p; }
    @Override public produit update(produit p) { return null; }
    @Override public boolean delete(long id) { return data.removeIf(x -> x.getId() == id); }
    @Override public produit findById(long id) {
        for (produit p : data) if (p.getId() == id) return p;
        return null;
    }
    @Override public List<produit> findAll() { return data; }
}